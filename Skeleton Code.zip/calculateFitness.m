function fitness = calculateFitness(population)
%takes in a population and calculates the fitness of each member 
%of the population by determining how many characters the current member of
%the population has compared to target phrase. We anticipate storing each
%individual organism's fitness in a vector the same length as the size of
%the population and having fitness values as percentages. 

fitness = 1;

end