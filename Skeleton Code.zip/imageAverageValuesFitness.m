function fitness = imageAverageValuesFitness(population)

%use the mean filter function to generate a "smoothed" version of the
%original and target image, then with a similar tolerance value as before, 
%compare each pixel to generate the fitness value for each "organism"

end