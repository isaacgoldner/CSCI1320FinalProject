function population = buildPopulation()
%creates a random population of 200 strings that are the same length as the
%target phrase. 

population = cell(1,1);
population{1,1} = 'sample string';

end 


