function imagePopulation = imageBuildPopulation(targetImage)

%generate 500 random images of same size as targetImage, the image that
%is to be generated,to build the
%initial population to begin the evolution process. 


end